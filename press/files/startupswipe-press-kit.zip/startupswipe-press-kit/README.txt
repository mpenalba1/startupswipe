StartupSwipe

StartupSwipe is a pixel art management game. Augusto puts you in charge of his startup with twenty-four thousand dollars and a garage. Every quarter, the board wants numbers. You can give them the ones you have, or the ones they’d like to see.

Developer: Maurizzio Peñalba
Platforms: iPhone, Android, Windows and macOS (Steam)
Release: Coming soon
Price: Chapter I is free on iPhone and Android, and the Full Game is one in-app purchase. On Steam, the whole game is one purchase.
Languages: English, Spanish and Italian
Contact: hello@startupswipegame.com

https://startupswipegame.com/

---

StartupSwipe es un juego de gestión en pixel art. Augusto te pone al frente de su startup con veinticuatro mil dólares y un garaje. Cada trimestre, la junta pide números. Puedes darles los que tienes, o los que les gustaría ver.

Desarrollo: Maurizzio Peñalba
Plataformas: iPhone, Android, Windows y macOS (Steam)
Lanzamiento: Próximamente
Precio: El capítulo I es gratis en iPhone y Android, y el Juego completo es una sola compra dentro del juego. En Steam, el juego completo es una sola compra.
Idiomas: Español, inglés e italiano
Contacto: hello@startupswipegame.com

https://startupswipegame.com/es/
